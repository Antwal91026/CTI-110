#CTI-110
#Anthony Wallace
#11-6-17
print ('Hello World')
